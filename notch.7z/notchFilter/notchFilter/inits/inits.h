/*
 * inits.h
 *
 * Created: 25.12.2019 18:24:57
 *  Author: Asus
 */ 


#ifndef INITS_H_
#define INITS_H_


void init();


#endif /* INITS_H_ */