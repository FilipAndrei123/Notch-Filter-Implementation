/*
 * BCD.h
 *
 * Created: 25.12.2019 18:38:01
 *  Author: Asus
 */ 


#ifndef BCD_H_
#define BCD_H_

void displayNumber(int value);



#endif /* BCD_H_ */