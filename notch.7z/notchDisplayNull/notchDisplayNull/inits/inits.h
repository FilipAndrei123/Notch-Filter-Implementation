/*
 * inits.h
 *
 * Created: 29.01.2020 15:41:45
 *  Author: Asus
 */ 


#ifndef INITS_H_
#define INITS_H_

void init();

#endif /* INITS_H_ */