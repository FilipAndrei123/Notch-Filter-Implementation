/*
 * notchDisplayNull.c
 *
 * Created: 18.01.2020 12:43:50
 * Author : Asus
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

